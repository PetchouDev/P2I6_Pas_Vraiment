#ifndef PUPPETUTILS_H
#define PUPPETUTILS_H

#include <Encoder.h> 
#include <Servo.h> 


// Classe pour asservir un moteur EMG30
// Classe pour asservir un moteur EMG30
class SlavedEngine {
    public:
        int destination = 0; // angle d'asservissement
        int position = 0; // position angulaire
        bool running = false; // état de l'asservissement
        Encoder* encoder; // pointeur vers le codeur

    private:
        // constantes
        const float kp = 1.25; // coefficient proportionnel
        const float ki = 0;   // coefficient intégral (non utilisé)
        const float kd = 0;  // coefficient dérivé (non utilisé)

        // erreur autorisée
        int error_threshold = 1; // erreur tolérée en degrés

        // paramètres physiques
        float pas = 40; // en mm/tour

        // variables
        long unsigned int t0 = 0; // temps précédent
        int previous_error = 0; // erreur précédente
        int integral = 0; // somme des erreurs

        // paramètres du moteur
        int power_pin; // pin de commande du moteur
        int direction_pin; // pin de direction du moteur

        int encoder_pin_1; // pin 1 du codeur
        int encoder_pin_2; // pin 2 du codeur

    public:
        SlavedEngine(int power_pin, int direction_pin, int encoder_pin_1, int encoder_pin_2, int error_threshold = 1, int pas = 40) {
            // initialisation du codeur
            this->encoder = new Encoder(encoder_pin_1, encoder_pin_2);

            // initialisation du moteur
            pinMode(power_pin, OUTPUT);
            digitalWrite(power_pin, LOW);

            pinMode(direction_pin, OUTPUT);

            // initialisation des paramètres
            this->error_threshold = mm_to_degrees(error_threshold);
            this->power_pin = power_pin;
            this->encoder_pin_1 = encoder_pin_1;
            this->encoder_pin_2 = encoder_pin_2;

            // initialisation des variables
            this->reset();
        }

        void set_destination(int dest) {
            this->destination = dest; // régler la destination sur scene en mm
        }

        void set_position(int pos) {
            this->position = pos; // définir la valeur de la position actuelle en mm
        }

        void reset() {
            this->destination = 0;
            this->position = 0;
            this->t0 = 0;
            this->integral = 0;
            this->encoder->write(0); // reset la position accumulée du codeur
        }

        void run() {
            // obtenir la position via le codeur du moteur
            this->position = this->encoder->read();

            // convertir la destination en degrés
            int dest = this->mm_to_degrees(this->destination);
            
            if (abs(this->destination - (this->position * this->pas)) > this->error_threshold) {
                // calcul de l'erreur
                int error = this->position - dest;

                // calcul de la commande
                float command = constrain(this->kp * error, -100, 100);

                // appliquer la commande
                this->power(command);

                /* Serial.print(dest);
                Serial.print(";");
                Serial.print(this->position);
                Serial.print(";");
                Serial.print(error);
                Serial.print(";");
                Serial.print(command);
                Serial.print(";");
                Serial.println(map(abs(command), 0, 100, 0, 255)); */

            // si suffisamment proche de la destination, arrêter le moteur
            } else {
                this->set_power(0);
            }
        }

        // Méthode pour convertir la commande pour le moteur
        void power(long percentage) {
            Serial.println(percentage);
            this->set_direction(percentage > 0);
            this->set_power(map(abs(percentage), 0, 100, 0, 255));
        }

    protected:
        // Méthode pour régler la puissance du moteur
        void set_power(int power) {
            Serial.println(power);
            analogWrite(this->power_pin, power);
        }

        // Méthode pour convertir les disnatances en degrés
        int mm_to_degrees(int mm) {
            return mm * 360 / this->pas;
        }

        // Méthode pour convertir les degrés en distances
        int degrees_to_mm(int degrees) {
            return degrees * this->pas / 360;
        }

        // Méthode pour régler la direction du moteur (x ⬈ => sens anti-horaire, x ⬊ => sens horaire)
        void set_direction(bool clockwise) {
            Serial.println(clockwise);
            digitalWrite(this->direction_pin, clockwise ? HIGH : LOW);
        }

        // Méthode pour calculer la commande
        float compute_command(int error, float derivative) {
            return constrain(this->kp * error + this->ki * this->integral + this->kd * derivative, -255, 255);
        }
};

// Classe pour contrôler un servo moteur
class ServoMotor {
    public:
        int pin; // pin du servo

    protected:
        Servo motor; // instance du servo
    
    public:
        // Constructeur
        ServoMotor(int angle_pin) {
            this->pin = pin; // pin du servo
            this->motor.attach(pin); // attacher le servo au pin
            pinMode(pin, OUTPUT); // définir le pin en sortie
        }

        // Méthode pour régler l'angle du servo
        void set_angle(int angle) {
            this->motor.write(angle);
        }

        // Méthode pour obtenir l'angle du servo
        int get_angle() {
            return this->motor.read();
        }

        // Méthode pour réinitialiser le servo
        void reset() {
            // remettre le servo à 90 (position neutre)
            this->motor.write(90);
        }
};

#endif